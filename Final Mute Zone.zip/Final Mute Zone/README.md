# Work Mode for Android

Work Mode is an app specially made for people who don't have time to silence their phone during work hours and reset the settings after work.

- Automatically silence your phone at the start of your work hours during work days
- Automatically return your phone's settings at the end of your work hours
- Enable or disable the app in one tap

## Installation

Download at [Play Store](https://play.google.com/store/apps/details?id=com.rafaelkarlo.workmode)

## Bugs?

Email me at rkdelossantos@gmail.com

## License

[MIT License](https://opensource.org/licenses/MIT)
