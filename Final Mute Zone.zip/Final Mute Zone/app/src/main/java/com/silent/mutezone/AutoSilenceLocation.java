package com.silent.mutezone;

public class AutoSilenceLocation {
    private int id;
    private String name, address;
    private double lat;
    private double lng;
    private float radius;
    private String requestId;

    AutoSilenceLocation(int id, String requestId, String name, double lat, double lng, float radius, String address) {
        this.name = name;
        this.requestId = requestId;
        this.address = address;
        this.lat = lat;
        this.lng = lng;
        this.id = id;
        this.radius = radius;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public double getLat() {
        return lat;
    }

    public double getLng() {
        return lng;
    }

    public float getRadius() {
        return radius;
    }

    public int getId() {
        return id;
    }

    public String getRequestId() {
        return requestId;
    }
}
