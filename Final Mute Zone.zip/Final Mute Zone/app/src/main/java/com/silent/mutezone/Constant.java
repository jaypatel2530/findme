package com.silent.mutezone;

public class Constant {
    public static String PREF="pref";
    public static String BASEURL="pref";
    public static String ID="id";
    public static String TYPE="type";
    public static String FNAME="fname";
    public static String LNAME="lname";
    public static String EMAIL="email";
    public static String CNO="contact";
    public static String STATUS="status";
    public static String NAME="name";

    public static final String Smtphostkey = "mail.smtp.host";
    public static final String SmatphostValue = "smtp.gmail.com";

    public static final String Sslsocketportkey = "mail.smtp.socketFactory.port";
    public static final String SslsocketportValue = "465";

    public static final String Sslclassfactorykey = "mail.smtp.socketFactory.class";
    public static final String SslclassfactoryValue = "javax.net.ssl.SSLSocketFactory";

    public static final String Sslauthnticationkey = "mail.smtp.auth";
    public static final String SslauthnticationValue = "true";

    public static final String Sslsmtpportkey = "mail.smtp.port";
    public static final String SslsmtpportValue = "587";

    public static final String OTPMessage = "Otp Verification Code :";
    public static final String OTPSUBJECT = "OTP From Mute Zone";

}
