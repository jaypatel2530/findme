package com.silent.mutezone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

public class splashActivity extends AppCompatActivity {
    private ProgressBar mProgress;
    SharedPreferences sp;

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Window window = getWindow();
        window.setFormat(PixelFormat.RGBA_8888);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        StartAnimations();
        sp = getSharedPreferences(Constant.PREF, MODE_PRIVATE);
        mProgress =findViewById(R.id.splash_screen_progress_bar);
        new Thread(new Runnable() {
            public void run() {
                doWork();
                startApp();
                finish();
            }
        }).start();
    }

    private void doWork() {
        for (int progress = 0; progress < 100; progress += 10) {
            try {
                Thread.sleep(300);
                mProgress.setProgress(progress);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void startApp() {
        if (sp.getString(Constant.ID, "").equalsIgnoreCase("")) {
            Intent intent = new Intent(splashActivity.this, homeActivity.class);
            startActivity(intent);
            finish();
        }
        else{
            Intent intent1 = new Intent(splashActivity.this, homeActivity.class);
            startActivity(intent1);
            finish();
        }
    }

    private void StartAnimations() {
        Animation anim = AnimationUtils.loadAnimation(this,R.anim.alpha);
        anim.reset();
        LinearLayout l =findViewById(R.id.lin_lay);
        l.clearAnimation();
        l.startAnimation(anim);

        anim = AnimationUtils.loadAnimation(this, R.anim.translate);
        anim.reset();
        ImageView iv =findViewById(R.id.logo);
        iv.clearAnimation();
        iv.startAnimation(anim);

    }
}
