package com.silent.mutezone.mainscreen.service.audio;

public enum AudioMode {
    NORMAL(2),
    VIBRATE(1),
    SILENT(0),
    UNKNOWN(-1);

    private int value;

    AudioMode(int intValue) {
        this.value = intValue;
    }

    public int getIntValue() {
        return value;
    }
}
