package com.silent.mutezone.mainscreen.config;

import com.silent.mutezone.mainscreen.service.alarm.WorkModeAlarmOnBootScheduler;
import com.silent.mutezone.mainscreen.service.alarm.WorkModeAlarmReceiver;
import com.silent.mutezone.mainscreen.view.MainActivity;

import javax.inject.Singleton;

import dagger.Component;

@Singleton
@Component(modules = {
        AndroidModule.class,
        WorkModeModule.class
})
public interface MainActivityComponent {
    void inject(MainActivity mainScreenActivity);
    void inject(WorkModeAlarmReceiver workModeAlarmReceiver);
    void inject(WorkModeAlarmOnBootScheduler workModeAlarmOnBootScheduler);
}
