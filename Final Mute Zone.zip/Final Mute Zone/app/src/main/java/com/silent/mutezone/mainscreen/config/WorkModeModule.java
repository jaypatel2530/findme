package com.silent.mutezone.mainscreen.config;

import android.app.AlarmManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;

import com.silent.mutezone.mainscreen.presenter.MainPresenterImpl;
import com.silent.mutezone.mainscreen.service.WorkModeAudioOverrideService;
import com.silent.mutezone.mainscreen.service.alarm.AlarmService;
import com.silent.mutezone.mainscreen.service.alarm.AlarmServiceImpl;
import com.silent.mutezone.mainscreen.service.alarm.WorkModeAlarm;
import com.silent.mutezone.mainscreen.service.audio.AudioModeService;
import com.silent.mutezone.mainscreen.service.time.WorkTimeService;
import com.silent.mutezone.mainscreen.service.time.WorkTimeServiceImpl;
import com.silent.mutezone.mainscreen.service.alarm.WorkModeAlarmImpl;
import com.silent.mutezone.mainscreen.service.alarm.WorkModeAlarmReceiver;
import com.silent.mutezone.mainscreen.service.WorkModeService;
import com.silent.mutezone.mainscreen.service.audio.AudioModeServiceImpl;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public class WorkModeModule {

    @Provides
    @Singleton
    public AudioModeService provideAudioModeService(AudioManager audioManager, SharedPreferences sharedPreferences) {
        return new AudioModeServiceImpl(audioManager, sharedPreferences);
    }

    @Provides
    @Singleton
    public WorkTimeService provideWorkTimeService(SharedPreferences sharedPreferences) {
        return new WorkTimeServiceImpl(sharedPreferences);
    }

    @Provides
    @Singleton
    public WorkModeService provideWorkModeService(AudioModeService audioModeService, WorkTimeService workTimeService, SharedPreferences sharedPreferences) {
        return new WorkModeService(audioModeService, workTimeService, sharedPreferences);
    }

    @Provides
    @Singleton
    public WorkModeAudioOverrideService provideWorkModeAudioOverrideService(AudioModeService audioModeService) {
        return new WorkModeAudioOverrideService(audioModeService);
    }

    @Provides
    @Singleton
    public MainPresenterImpl provideMainPresenter(WorkModeService workModeService, WorkModeAlarm workModeAlarm, WorkModeAudioOverrideService workModeAudioOverrideService) {
        return new MainPresenterImpl(workModeService, workModeAlarm, workModeAudioOverrideService);
    }

    @Provides
    @Singleton
    public AlarmService provideAlarmService(Context context, AlarmManager alarmManager) {
        return new AlarmServiceImpl(context, alarmManager);
    }

    @Provides
    @Singleton
    public WorkModeAlarm provideWorkModeAlarm(AlarmService alarmService) {
        return new WorkModeAlarmImpl(alarmService);
    }

    @Provides
    @Singleton
    public WorkModeAlarmReceiver provideWorkModeAlarmReceiver() {
        return new WorkModeAlarmReceiver();
    }

}
