package com.silent.mutezone.mainscreen.presenter;

import com.silent.mutezone.mainscreen.service.audio.AudioMode;
import com.silent.mutezone.mainscreen.service.time.WorkDay;
import com.silent.mutezone.mainscreen.view.MainView;

import java.util.Set;

public interface MainPresenter {

    void onCreate();
    void attachView(MainView mainView);
    void activateWorkMode();
    void deactivateWorkMode();
    void setStartDate(int hour, int minute);
    void setEndDate(int hour, int minute);

    void setWorkDays(Set<WorkDay> workDays);

    Set<WorkDay> getSavedDays();

    void setCurrentAudioMode(AudioMode audioMode);
}
