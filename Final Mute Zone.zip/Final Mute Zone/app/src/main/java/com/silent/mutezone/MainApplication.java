package com.silent.mutezone;

import android.app.Application;

import com.silent.mutezone.mainscreen.config.AndroidModule;
import com.silent.mutezone.mainscreen.config.DaggerMainActivityComponent;
import com.silent.mutezone.mainscreen.config.MainActivityComponent;
import com.silent.mutezone.mainscreen.config.WorkModeModule;

public class MainApplication extends Application {

    MainActivityComponent mainActivityComponent;

    @Override
    public void onCreate() {
        super.onCreate();
        mainActivityComponent = DaggerMainActivityComponent.builder()
                .androidModule(new AndroidModule(this))
                .workModeModule(new WorkModeModule())
                .build();
    }

    public MainActivityComponent getMainActivityComponent() {
        return mainActivityComponent;
    }
}
